<body class="horizontal-layout horizontal-menu <?php echo e($configData['horizontalMenuType']); ?> <?php echo e($configData['blankPageClass']); ?>

<?php echo e($configData['bodyClass']); ?>  <?php echo e(($configData['theme'] === 'light') ? '' : $configData['layoutTheme']); ?>

<?php echo e($configData['sidebarClass']); ?> <?php echo e($configData['verticalMenuNavbarType']); ?> <?php echo e($configData['footerType']); ?>" data-menu="horizontal-menu" data-col="<?php echo e($configData['showMenu'] === true ? '' : '1-column'); ?>" data-open="hover" data-layout="<?php echo e($configData['theme']); ?>" style="<?php echo e($configData['bodyStyle']); ?>" data-framework="laravel">

  
  <?php if((isset($configData['showMenu']) && $configData['showMenu'] === true)): ?>
  <?php echo $__env->make('panels.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <!-- BEGIN: Header-->
  
  <?php echo $__env->make('panels.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
  <?php echo $__env->make('panels.horizontalMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- BEGIN: Content-->
  <div class="app-content content">
    <!-- BEGIN: Header-->
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>

    <div class="content-wrapper">
      
      <?php if($configData['pageHeader'] == true && isset($configData['pageHeader'])): ?>
      <?php echo $__env->make('panels.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endif; ?>
      <div class="<?php echo e($configData['sidebarPositionClass']); ?>">
        <div class="sidebar">
          
          <?php echo $__env->yieldContent('content-sidebar'); ?>
        </div>
      </div>
      <div class="<?php echo e($configData['contentsidebarClass']); ?>">
        <div class="content-body">
          
          <?php echo $__env->yieldContent('content'); ?>
        </div>
      </div>
    </div>
  </div>
  <!-- End: Content-->

  <?php if($configData['blankPage'] == false): ?>
  <?php echo $__env->make('content/pages/customizer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('content/pages/buy-now', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <div class="sidenav-overlay"></div>
  <div class="drag-target"></div>

  
  <?php echo $__env->make('panels/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  
  <?php echo $__env->make('panels/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script type="text/javascript">
    $(window).on('load', function() {
      if (feather) {
        feather.replace({
          width: 14
          , height: 14
        });
      }
    })

  </script>
</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views/layouts/horizontalDetachedLayoutMaster.blade.php ENDPATH**/ ?>